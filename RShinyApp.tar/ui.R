# ui.R

library(shiny)
library(ggplot2)

ui <- fluidPage(
  titlePanel("Attrition Predictor"),
  sidebarLayout(
    sidebarPanel(
      numericInput("new_OT", "Is employee Overtime Employee? 0 = No, 1 = Yes:", value = 0),
      numericInput("new_JobLevel", "Enter JobLevel: 1 = Entry Level, 5 = Executive", value = 0),
      numericInput("new_JobInvolvement", "Enter JobInvolvement: Scale of 1 to 4", value = 0),
      numericInput("new_U30", "Is employee younger than 30? 0 = No, 1 = Yes:", value = 0),
      actionButton("predict_button", "Predict"),
      verbatimTextOutput("prediction_output")
    ),
    mainPanel(
      plotOutput("regression_plot")
    )
  )
)
