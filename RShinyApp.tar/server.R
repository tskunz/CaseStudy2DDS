# Install necessary packages if not installed
# install.packages(c("shiny", "ggplot2", "broom"))

library(shiny)
library(ggplot2)
library(broom)
library(RCurl)
library(tidyverse)
library(stats)
library(caret)
library(e1071)
library(class)
library(pROC)

# Load in data set from Amazon S3
cs2data = read.csv("https://s3.us-east-2.amazonaws.com/msds.ds.6306.2/CaseStudy2-data.csv", stringsAsFactors = TRUE)


#creating a binary fields to assist with classification.
cs2data$AttrBin = ifelse(cs2data$Attrition == "Yes", 1, 0)
cs2data$MF = ifelse(cs2data$Gender == "Male", 1, 0)
cs2data$OT = ifelse(cs2data$OverTime == "Yes", 1, 0)
cs2data$o18 = ifelse(cs2data$Over18 == "Y", 1, 0)
cs2data$Married = ifelse(cs2data$MaritalStatus == "Married", 1, 0)
cs2data$Divorced = ifelse(cs2data$MaritalStatus == "Divorced", 1, 0)
cs2data$Travel = as.numeric(cs2data$BusinessTravel) - 1
cs2data$RND = ifelse(cs2data$Department == "Research & Development", 1, 0)
cs2data$Sales = ifelse(cs2data$Department == "Sales", 1, 0)
cs2data$U30 = ifelse(cs2data$Age < 30, 1, 0)
cs2data$U35 = ifelse(cs2data$Age < 35, 1, 0)
cs2data$U40 = ifelse(cs2data$Age < 40, 1, 0)
cs2data$O45 = ifelse(cs2data$Age > 45, 1, 0)
cs2data$Attrition = relevel(cs2data$Attrition, ref = "Yes")
cs2data$L10 = ifelse(cs2data$TotalWorkingYears <= 10, 1, 0)

# Set seed for replicability
set.seed(23)

# Fit the model
model <- lm(AttrBin ~ OT + JobLevel + JobInvolvement + U30, data = cs2data)

shinyServer(function(input, output) {
  # Reactive expression for the regression plot
  output$regression_plot <- renderPlot({
    ggplot(cs2data, aes(x = OT, y = AttrBin)) +
      geom_point() +
      geom_smooth(method = "lm", se = FALSE, color = "blue") +
      geom_point(aes(x = input$new_OT, y = as.numeric(input$predict_button)), color = "red", size = 3) +
      geom_hline(yintercept = 0.2, linetype = "dotted", color = "red") +
      geom_ribbon(aes(ymax = Inf, ymin = 0.2), fill = "lightcoral", alpha = 0.5) +
      coord_cartesian(xlim = c(0, 1), ylim = c(0, 1))
  })

  
  # Reactive expression for the prediction
  output$prediction_output <- renderText({
    req(input$predict_button)
    new_data <- data.frame(
      OT = input$new_OT,
      JobLevel = input$new_JobLevel,
      JobInvolvement = input$new_JobInvolvement,
      U30 = input$new_U30
    )
    prediction <- predict(model, newdata = new_data)
    # Change the threshold as needed
    result <- ifelse(prediction >= 0.2, "Attrition", "Retention")
    
    paste(result)
  })
})
