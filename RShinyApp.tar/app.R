library(shiny)
shiny::runApp("C:/Users/tkchu/Desktop/folder/TKunzProject2_files/RShiny/FritoLayAttritionShiny")
